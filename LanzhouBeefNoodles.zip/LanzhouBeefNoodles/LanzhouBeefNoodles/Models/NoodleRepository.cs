﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LanzhouBeefNoodles.Models
{
    public class NoodleRepository : INoodleRepository
    {
        private readonly AppDbContext _dbContext;

        public NoodleRepository(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<Noodle> GetAllNoodles()
        {
            return _dbContext.Noodles;
        }

        public Noodle GetNoodleById(int id)
        {
            return _dbContext.Noodles.FirstOrDefault(n=>n.Id == id);
        }
    }
}
