﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LanzhouBeefNoodles.Models
{
    public class MockFeedBackRepository : IFeedBackRepository
    {
        private List<FeedBack> _feedBacks;

        public MockFeedBackRepository()
        {
            if (_feedBacks == null)
            {
                _feedBacks = new List<FeedBack>
                {
                    new FeedBack{Id=1,Name="欧耶1",Email="1231@qq.com" },
                    new FeedBack{Id=2,Name="欧耶2",Email="1232@qq.com" },
                    new FeedBack{Id=3,Name="欧耶3",Email="1233@qq.com" },
                    new FeedBack{Id=4,Name="欧耶4",Email="1234@qq.com" },
                    new FeedBack{Id=5,Name="欧耶5",Email="1235@qq.com" },
                    new FeedBack{Id=6,Name="欧耶6",Email="1236@qq.com" }
                };
            }
        }

        public IEnumerable<FeedBack> GetAllFeedBacks()
        {
            return _feedBacks;
        }
    }
}
