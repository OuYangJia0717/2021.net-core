﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LanzhouBeefNoodles.Models
{
    public class MockNoodleRepository : INoodleRepository
    {
        private List<Noodle> _noodles;

        public MockNoodleRepository() 
        {
            if (_noodles == null)
            {
                InitializeNoodle();
            }
        }

        private void InitializeNoodle() 
        {
            _noodles = new List<Noodle>
            {
                new Noodle { Id =1,Name="面条一",Price=1,ShortDescription="面条一短描述",LongDescription="面条一长描述",ImageURL=""},
                new Noodle { Id =2,Name="面条二",Price=2,ShortDescription="面条二短描述",LongDescription="面条二长描述",ImageURL=""},
                new Noodle { Id =3,Name="面条三",Price=3,ShortDescription="面条三短描述",LongDescription="面条三长描述",ImageURL=""},
                new Noodle { Id =4,Name="面条四",Price=4,ShortDescription="面条四短描述",LongDescription="面条四长描述",ImageURL=""},
                new Noodle { Id =5,Name="面条五",Price=5,ShortDescription="面条五短描述",LongDescription="面条五长描述",ImageURL=""},
                new Noodle { Id =6,Name="面条六",Price=6,ShortDescription="面条六短描述",LongDescription="面条六长描述",ImageURL=""},
                new Noodle { Id =7,Name="面条七",Price=7,ShortDescription="面条七短描述",LongDescription="面条七长描述",ImageURL=""},
            };
        }

        public IEnumerable<Noodle> GetAllNoodles()
        {
            return _noodles;
        }

        public Noodle GetNoodleById(int id)
        {
            return _noodles.FirstOrDefault(n=> n.Id ==id);
        }
    }
}
