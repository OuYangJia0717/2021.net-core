﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace LanzhouBeefNoodles.Coltrollers
{
    [Route("[controller]/[action]")]
    public class HomeController : Controller
    {
        public string Index()
        {
            return "Hello From Home Index";
        }

        public string About() 
        {
            return "Hellp From Home About";
        }
    }
}
