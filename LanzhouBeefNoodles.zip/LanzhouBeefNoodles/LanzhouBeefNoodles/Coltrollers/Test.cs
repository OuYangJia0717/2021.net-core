﻿using LanzhouBeefNoodles.Models;
using LanzhouBeefNoodles.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LanzhouBeefNoodles.Coltrollers
{
    public class Test:Controller
    {
        private INoodleRepository _noodleRepository;
        private IFeedBackRepository _feedBackRepository;

        public Test(INoodleRepository noodleRepository,IFeedBackRepository feedBackRepository) 
        {
            _noodleRepository = noodleRepository;
            _feedBackRepository = feedBackRepository;
        }

        public ActionResult Index()
        {
            return View(new HomeViewModel
            {
                Noodles = _noodleRepository.GetAllNoodles().ToList(),
                FeedBacks = _feedBackRepository.GetAllFeedBacks().ToList()
            }); ;
        }
    }
}
